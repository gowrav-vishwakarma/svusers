<?php
class Exception_Filestore_Type extends Exception_Filestore{}

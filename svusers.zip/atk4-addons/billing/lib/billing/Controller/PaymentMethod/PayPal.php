<?php
class billing_Controller_PaymentMethod_PayPal extends ATK3_Controller{
	protected $model_name='billing_Model_PaymentMethod_PayPal';
}

<?php

class Model_DistributorA extends Model_Distributor {}